import os

log_path = '/home/michael/Desktop/result.txt'

with open(log_path, 'a') as f:
	f.write('worked')
