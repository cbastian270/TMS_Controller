import os

log_path = '/home/michael/Desktop/result.txt'

with open(log_path, 'a') as f:
        f.write('This is the test script writing')
